Dear <?php echo e($variableName); ?>,<br>

<br>Welcome to Our Website! We're thrilled to have you as a new member of our community.<br>

Thank you for joining us. Here are your account details:<br>

Username: <?php echo e($variableName); ?><br>
Email: <?php echo e($variableEmail); ?><br>
Please feel free to explore our website and take advantage of all the features we have to offer.<br>

If you have any questions or need assistance, don't hesitate to reach out to our support team at ezzeldeenmohamed896@gmail.com.<br>

<br>Once again, welcome aboard!<br>

Best regards,<br>
FCAI Team<?php /**PATH C:\RegistrationForm\resources\views/mail/new_registered_user.blade.php ENDPATH**/ ?>