<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
      <a class="navbar-brand" href="#">3zoz</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
              <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
              </li>
              <?php if(auth()->guard()->check()): ?>
              <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('logout')); ?>" ><?php echo e(__('Logout')); ?></a>
              </li>
              <?php else: ?>
              <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('registration')); ?>"><?php echo e(__('Register')); ?></a>
              </li>
              <?php endif; ?>
          </ul>
          <div id="languageToggle" class="navbar-text ms-auto d-flex">
            <button onclick="toggleLanguage()">Toggle Language</button>
          </div>
          <span class="navbar-text ms-auto d-flex">
              <?php if(auth()->guard()->check()): ?>
              Hi, <?php echo e(auth()->user()->user_name); ?>

              <?php endif; ?>
          </span>
      </div>
  </div>
</nav>
<script>
    function toggleLanguage() {
        var currentLang = document.documentElement.lang;
        var newLang = currentLang === 'en' ? 'ar' : 'en';
        window.location.href = "<?php echo e(url('lang/')); ?>" + newLang;
    }
</script><?php /**PATH D:\Collage\ThirdYear\Semster 2\Web2\Laravel_Project_Registration\RegistrationForm\resources\views/Include/header.blade.php ENDPATH**/ ?>