<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">3zoz</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?php echo e(route('home')); ?>">Home</a>
          </li>
          <?php if(auth()->guard()->check()): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>" >Logout</a>
            </li>
          <?php else: ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('registration')); ?>">Register</a>
            </li>
          <?php endif; ?>
        </ul>
        <span class="navbar-text">
            <?php if(auth()->guard()->check()): ?>
                <?php echo e(auth()->user()->user_name); ?>

            <?php endif; ?>
        </span>
      </div>
    </div>
  </nav><?php /**PATH C:\RegistrationForm\resources\views/Include/header.blade.php ENDPATH**/ ?>