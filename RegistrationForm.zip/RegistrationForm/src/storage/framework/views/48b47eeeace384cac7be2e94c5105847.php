<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
<section class="hero">
    <div class="container text-center">
        <h2>Welcome to our website</h2>
        <p class="lead">This project is a collage of efforts aimed at discouraging students from studying for their final exams.</p>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\RegistrationForm\resources\views/welcome.blade.php ENDPATH**/ ?>