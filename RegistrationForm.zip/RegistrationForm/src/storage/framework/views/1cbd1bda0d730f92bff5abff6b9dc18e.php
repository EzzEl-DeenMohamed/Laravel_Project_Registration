<!DOCTYPE html>
<html>
<head>
    <title>Happy Birthday!</title>
</head>
<body>
<p>Dear <?php echo e($variableName); ?>,</p>

<p>Happy Birthday!</p>

<p>We are thrilled to celebrate your special day with you. As a token of our appreciation, we are sending you a special gift to your location at <?php echo e($address); ?>.</p>

<p>Your gift is: Srer B doreen</p>

<p>Here are your account details:</p>

<p>
    Username: <?php echo e($variableName); ?><br>
    Email: <?php echo e($variableEmail); ?><br>
    Birthdate: <?php echo e($birthdate); ?><br>
    Address: <?php echo e($address); ?><br>
</p>

<p>Please feel free to explore our website and take advantage of all the features we have to offer.</p>

<p>If you have any questions or need assistance, don't hesitate to reach out to our support team at ezzeldeenmohamed896@gmail.com.</p>

<p>Once again, happy birthday and welcome aboard!</p>

<p>Best regards,</p>

<p>FCAI Team</p>
</body>
</html>
<?php /**PATH D:\Collage\ThirdYear\Semster 2\Web2\Laravel_Project_Registration\RegistrationForm\resources\views/mail/HappyBirthday.blade.php ENDPATH**/ ?>