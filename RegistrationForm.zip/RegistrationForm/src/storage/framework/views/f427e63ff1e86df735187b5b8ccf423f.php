<div style="position: fixed;bottom:0;">
    <footer>
        <!-- Your footer content here -->
        <p>&copy; <?php echo e(__('FCAI Group')); ?></p>
    </footer>
</div>
<!-- <script src="assets/js/jquery.min.js"></script> -->
</body>
</html><?php /**PATH D:\Collage\ThirdYear\Semster 2\Web2\Laravel_Project_Registration\RegistrationForm\src\resources\views/Include/footer.blade.php ENDPATH**/ ?>