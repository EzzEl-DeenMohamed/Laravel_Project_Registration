<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
      <a class="navbar-brand" href="#"><?php echo e(__('3zoz')); ?></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
              <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
              </li>
              <?php if(auth()->guard()->check()): ?>
              <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('logout')); ?>" ><?php echo e(__('Logout')); ?></a>
              </li>
              <?php else: ?>
              <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('registration')); ?>"><?php echo e(__('Register')); ?></a>
              </li>
              <?php endif; ?>
              <li class="nav-item">
                <a id="language-toggle" class="nav-link" href="locale/en" >English</a>
              </li>
              <li class="nav-item">
                <a id="language-toggle" class="nav-link" href="locale/ar" >Arabic</a>
              </li>
          </ul>
          <span class="navbar-text ms-auto d-flex">
              <?php if(auth()->guard()->check()): ?>
              <?php echo e(__('Hi,')); ?> <?php echo e(auth()->user()->user_name); ?>

              <?php endif; ?>
          </span>
      </div>
  </div>
</nav>
<?php /**PATH D:\Collage\ThirdYear\Semster 2\Web2\Laravel_Project_Registration\RegistrationForm\resources\views/Include/header.blade.php ENDPATH**/ ?>