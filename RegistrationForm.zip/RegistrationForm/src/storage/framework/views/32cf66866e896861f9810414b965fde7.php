
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
<section class="hero">
    <div class="container text-center">
        <h2><?php echo e(__('Admin Place')); ?></h2>
        <p class="lead"><?php echo e(__('Admin Place this is for 3zoz only.')); ?></p>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Collage\ThirdYear\Semster 2\Web2\Laravel_Project_Registration\RegistrationForm\resources\views/admin.blade.php ENDPATH**/ ?>