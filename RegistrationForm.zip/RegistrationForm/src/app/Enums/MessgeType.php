<?php

namespace App\Enums;

enum MessageType: string {
    case EMAIL = '1';
    case PHONE = '2';
}
