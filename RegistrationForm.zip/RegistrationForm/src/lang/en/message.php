<?php

return [
    "Welcome to our website"=> "Welcome to our website",
    'Home'=> 'Home',
    "About"=> "About",
    "Contact"=> "Contact",
    "Services"=> "Services",
    "Login"=> "Login",
    "Register"=> "Register",
    "Logout"=> "Logout",
    "Email address"=> "Email address",
    "We'll never share your email with anyone else."=> "We'll never share your email with anyone else.",
    "Password"=> "Password",
    "Check me out"=> "Check me out",
    "Submit"=> "Submit",
    "Full Name"=> "Full Name",
    "Username"=> "Username",
    "Birthdate"=> "Birthdate",
    "Check Actors Born Today"=> "Check Actors Born Today",
    "Phone"=> "Phone",
    "Address"=> "Address",
    "Confirm Password"=> "Confirm Password",
    "User Image"=> "User Image",
    "Choose File"=> "Choose File",
    "No File Chosen"=> "No File Chosen",
    "FCAI Group"=> "FCAI Group",
    "Toggle Language"=> "Toggle Language"
];

?>