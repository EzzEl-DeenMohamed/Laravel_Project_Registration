<div style="position: fixed;bottom:0;">
    <footer>
        <!-- Your footer content here -->
        <p>&copy; {{__('FCAI Group')}}</p>
    </footer>
</div>
<!-- <script src="assets/js/jquery.min.js"></script> -->
</body>
</html>