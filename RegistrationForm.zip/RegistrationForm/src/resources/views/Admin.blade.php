@extends('layout')
@section('title', 'Home')
@section('content')
<section class="hero">
    <div class="container text-center">
        <h2>{{__('Admin Place')}}</h2>
        <p class="lead">{{__('Admin Place this is for 3zoz only.')}}</p>
    </div>
</section>

@endsection