<!DOCTYPE html>
<html>
<head>
    <title>Happy Birthday!</title>
</head>
<body>
<p>Dear {{ $variableName }},</p>

<p>Happy Birthday!</p>

<p>We are thrilled to celebrate your special day with you. As a token of our appreciation, we are sending you a special gift to your location at {{ $address }}.</p>

<p>Your gift is: Srer B doreen</p>

<p>Here are your account details:</p>

<p>
    Username: {{ $variableName }}<br>
    Email: {{ $variableEmail }}<br>
    Birthdate: {{ $birthdate }}<br>
    Address: {{ $address }}<br>
</p>

<p>Please feel free to explore our website and take advantage of all the features we have to offer.</p>

<p>If you have any questions or need assistance, don't hesitate to reach out to our support team at ezzeldeenmohamed896@gmail.com.</p>

<p>Once again, happy birthday and welcome aboard!</p>

<p>Best regards,</p>

<p>FCAI Team</p>
</body>
</html>
